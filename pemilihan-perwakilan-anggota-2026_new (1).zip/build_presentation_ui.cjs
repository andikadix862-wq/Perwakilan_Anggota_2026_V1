// Node script to build presentation-ui.html
const fs = require('fs');
const path = require('path');

const css = `
:root {
  --primary: #1E3A8A;
  --primary-dark: #0F172A;
  --primary-light: #3B82F6;
  --accent: #0284C7;
  --success: #10B981;
  --warning: #F59E0B;
  --danger: #EF4444;
  --bg-dark: #0B132B;
  --bg-stage: #0F172A;
  --bg-card: #1E293B;
  --border: #334155;
  --border-light: rgba(148, 163, 184, 0.2);
  --text-main: #F8FAFC;
  --text-muted: #94A3B8;
  --mockup-bg: #FFFFFF;
  --mockup-text: #0F172A;
  --slide-ratio: 16 / 9;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  -webkit-font-smoothing: antialiased;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  background-color: var(--bg-dark);
  color: var(--text-main);
  height: 100vh;
  width: 100vw;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  user-select: none;
}

/* Header Bar */
.pres-header {
  height: 50px;
  background: rgba(15, 23, 42, 0.95);
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  z-index: 50;
  backdrop-filter: blur(8px);
}

.pres-brand {
  display: flex;
  align-items: center;
  gap: 12px;
}

.pres-badge {
  background: #1E3A8A;
  color: #93C5FD;
  font-size: 11px;
  font-weight: 800;
  padding: 4px 10px;
  border-radius: 6px;
  letter-spacing: 1px;
  border: 1px solid rgba(147, 197, 253, 0.3);
}

.pres-title-header {
  font-size: 13px;
  font-weight: 700;
  color: #E2E8F0;
  letter-spacing: 0.5px;
}

.pres-tools {
  display: flex;
  align-items: center;
  gap: 8px;
}

.btn-tool {
  background: rgba(30, 58, 138, 0.4);
  border: 1px solid var(--border);
  color: #CBD5E1;
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.2s;
}

.btn-tool:hover {
  background: #1E3A8A;
  color: #FFF;
  border-color: #3B82F6;
}

/* Progress bar */
.progress-container {
  width: 100%;
  height: 4px;
  background: rgba(255, 255, 255, 0.08);
}

.progress-bar {
  height: 100%;
  background: linear-gradient(90deg, #3B82F6, #10B981);
  width: 6.25%;
  transition: width 0.3s ease;
}

/* Presentation Stage */
.stage-container {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 14px 24px;
  position: relative;
  overflow: hidden;
}

.slide-viewport {
  width: 100%;
  max-width: 1280px;
  height: 100%;
  max-height: 720px;
  aspect-ratio: var(--slide-ratio);
  position: relative;
}

.slide {
  position: absolute;
  inset: 0;
  background: var(--bg-stage);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 28px 36px;
  display: none;
  flex-direction: column;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
  opacity: 0;
  transform: scale(0.985) translateY(8px);
  transition: opacity 0.3s ease, transform 0.3s ease;
  overflow-y: auto;
}

.slide.active {
  display: flex;
  opacity: 1;
  transform: scale(1) translateY(0);
}

/* Typography */
.slide-tag {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  font-weight: 800;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: #60A5FA;
  margin-bottom: 6px;
}

.slide-title {
  font-size: 26px;
  font-weight: 900;
  color: #FFFFFF;
  letter-spacing: -0.5px;
  line-height: 1.25;
  margin-bottom: 6px;
}

.slide-subtitle {
  font-size: 13px;
  color: var(--text-muted);
  margin-bottom: 18px;
  max-width: 950px;
  line-height: 1.45;
}

.slide-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

/* Layout Grids */
.grid-2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}

.grid-3 {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.grid-4 {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 14px;
}

/* Mockup Windows (Browser Frame) */
.browser-frame {
  background: #FFFFFF;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 16px 32px rgba(0, 0, 0, 0.35);
  border: 1px solid #CBD5E1;
  display: flex;
  flex-direction: column;
  color: #0F172A;
}

.browser-header {
  background: #F1F5F9;
  padding: 8px 14px;
  border-bottom: 1px solid #E2E8F0;
  display: flex;
  align-items: center;
  gap: 10px;
}

.window-dots {
  display: flex;
  align-items: center;
  gap: 6px;
}

.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}
.dot-red { background: #EF4444; }
.dot-yellow { background: #F59E0B; }
.dot-green { background: #10B981; }

.browser-address {
  flex: 1;
  background: #FFFFFF;
  border: 1px solid #CBD5E1;
  border-radius: 6px;
  padding: 3px 10px;
  font-size: 11px;
  color: #475569;
  font-family: monospace;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.browser-content {
  padding: 16px;
  background: #F8FAFC;
  flex: 1;
  overflow-y: auto;
}

/* Smartphone Mockup Frame */
.phone-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
}

.phone-frame {
  width: 320px;
  height: 520px;
  background: #000000;
  border-radius: 36px;
  padding: 12px;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7), inset 0 0 2px 2px #334155;
  position: relative;
}

.phone-notch {
  width: 120px;
  height: 18px;
  background: #000000;
  border-bottom-left-radius: 12px;
  border-bottom-right-radius: 12px;
  position: absolute;
  top: 12px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 10;
}

.phone-screen {
  width: 100%;
  height: 100%;
  background: #F8FAFC;
  border-radius: 26px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  color: #0F172A;
}

.phone-top-bar {
  height: 28px;
  background: #1E3A8A;
  color: #FFF;
  font-size: 10px;
  font-weight: 700;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  padding: 0 16px 4px 16px;
}

.phone-content {
  flex: 1;
  padding: 14px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
}

/* Cards & Widgets */
.ui-card {
  background: #FFFFFF;
  border: 1px solid #E2E8F0;
  border-radius: 10px;
  padding: 16px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
}

.stat-box {
  background: #FFFFFF;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  padding: 12px 14px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.stat-box .title {
  font-size: 10.5px;
  font-weight: 700;
  color: #64748B;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.stat-box .num {
  font-size: 22px;
  font-weight: 900;
  color: #0F172A;
  margin-top: 4px;
}

/* UI Elements */
.btn-primary-mockup {
  background: #1E3A8A;
  color: #FFFFFF;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 0.5px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

.btn-success-mockup {
  background: #059669;
  color: #FFFFFF;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 800;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.input-mockup {
  width: 100%;
  background: #FFFFFF;
  border: 1.5px solid #CBD5E1;
  border-radius: 8px;
  padding: 10px 14px;
  font-size: 13px;
  color: #334155;
  margin-bottom: 12px;
}

.radio-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 14px;
  background: #FFFFFF;
  border: 1.5px solid #E2E8F0;
  border-radius: 8px;
  margin-bottom: 8px;
  transition: all 0.2s;
}

.radio-row.checked {
  border-color: #1E3A8A;
  background: #EFF6FF;
}

.radio-dot {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid #94A3B8;
  display: flex;
  align-items: center;
  justify-content: center;
}

.radio-row.checked .radio-dot {
  border-color: #1E3A8A;
}

.radio-dot-inner {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: transparent;
}

.radio-row.checked .radio-dot-inner {
  background: #1E3A8A;
}

.badge-tag {
  display: inline-block;
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 10px;
  font-weight: 800;
  text-transform: uppercase;
}

.badge-active { background: #DCFCE7; color: #166534; border: 1px solid #86EFAC; }
.badge-unvoted { background: #FEF3C7; color: #92400E; border: 1px solid #FCD34D; }
.badge-voted { background: #DBEAFE; color: #1E40AF; border: 1px solid #93C5FD; }

/* Table Mockup */
.mock-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 11.5px;
  background: #FFFFFF;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid #E2E8F0;
}

.mock-table th {
  background: #F8FAFC;
  color: #475569;
  padding: 8px 10px;
  text-align: left;
  font-weight: 700;
  border-bottom: 1px solid #E2E8F0;
}

.mock-table td {
  padding: 8px 10px;
  border-bottom: 1px solid #F1F5F9;
  color: #1E293B;
}

.mock-table tr:last-child td {
  border-bottom: none;
}

/* Bar chart row */
.chart-bar-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 8px;
}
.chart-name {
  width: 130px;
  font-size: 11px;
  font-weight: 700;
  color: #1E293B;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.chart-track {
  flex: 1;
  height: 20px;
  background: #E2E8F0;
  border-radius: 4px;
  overflow: hidden;
  position: relative;
}
.chart-fill {
  height: 100%;
  border-radius: 4px;
  background: #1E3A8A;
  display: flex;
  align-items: center;
  padding-left: 8px;
  color: #FFF;
  font-size: 10px;
  font-weight: 800;
}
.chart-fill.elected {
  background: #059669;
}

/* Footer Controls */
.pres-footer {
  height: 52px;
  background: rgba(15, 23, 42, 0.95);
  border-top: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  z-index: 50;
}

.footer-info {
  font-size: 12px;
  color: var(--text-muted);
  display: flex;
  align-items: center;
  gap: 12px;
}

.footer-counter {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-weight: 800;
  font-size: 13px;
  color: #60A5FA;
  background: rgba(30, 58, 138, 0.35);
  padding: 4px 12px;
  border-radius: 6px;
  border: 1px solid rgba(59, 130, 246, 0.3);
}

.footer-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.btn-nav {
  background: #1E3A8A;
  color: #FFF;
  border: 1px solid #3B82F6;
  padding: 7px 16px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 700;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.2s;
}

.btn-nav:hover:not(:disabled) {
  background: #2563EB;
  box-shadow: 0 0 10px rgba(59, 130, 246, 0.4);
}

.btn-nav:disabled {
  opacity: 0.35;
  cursor: not-allowed;
  background: #1E293B;
  border-color: #334155;
}

/* Overview modal */
.overview-overlay {
  position: fixed;
  inset: 0;
  background: rgba(11, 19, 43, 0.96);
  backdrop-filter: blur(10px);
  z-index: 100;
  display: none;
  padding: 24px 32px;
  flex-direction: column;
  overflow-y: auto;
}

.overview-overlay.open {
  display: flex;
}

.overview-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
  margin-top: 18px;
}

.overview-card {
  background: #1E293B;
  border: 1px solid #334155;
  border-radius: 10px;
  padding: 14px;
  cursor: pointer;
  transition: all 0.2s;
}

.overview-card:hover, .overview-card.active {
  border-color: #3B82F6;
  background: #1E3A8A;
  transform: translateY(-2px);
}

.overview-card .num {
  font-size: 11px;
  font-weight: 800;
  color: #60A5FA;
  margin-bottom: 4px;
}

.overview-card .name {
  font-size: 13px;
  font-weight: 700;
  color: #F8FAFC;
}

@media print {
  body {
    background: #FFF !important;
    color: #000 !important;
    overflow: visible !important;
    height: auto !important;
  }
  .pres-header, .pres-footer, .progress-container, .overview-overlay {
    display: none !important;
  }
  .stage-container { padding: 0 !important; }
  .slide-viewport { max-width: 100% !important; height: auto !important; }
  .slide {
    display: block !important;
    position: relative !important;
    opacity: 1 !important;
    transform: none !important;
    background: #FFF !important;
    color: #000 !important;
    border: 1px solid #CCC !important;
    page-break-after: always !important;
    margin-bottom: 30px !important;
  }
}
`;

const slides = [
  // SLIDE 1: COVER
  {
    tag: 'RANCANGAN ANTARMUKA APLIKASI',
    title: 'MOCKUP INTERFACE SISTEM PEMILIHAN ANGGOTA',
    subtitle: 'Rancangan Tampilan Portal Anggota dan Portal Admin untuk bahan evaluasi & persetujuan manajemen.',
    html: `
      <div style="text-align: center; margin: auto 0; padding: 20px 0;">
        <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(59, 130, 246, 0.15); border: 1px solid rgba(59, 130, 246, 0.4); padding: 8px 18px; border-radius: 9999px; font-size: 13px; font-weight: 800; color: #93C5FD; margin-bottom: 24px; letter-spacing: 1px;">
          KOPSYAH PT YKK AP INDONESIA
        </div>
        <h1 style="font-size: 40px; font-weight: 900; color: #FFFFFF; line-height: 1.25; margin-bottom: 16px; letter-spacing: -0.5px;">
          MOCKUP SISTEM PEMILIHAN ANGGOTA<br/>
          <span style="color: #60A5FA;">PERWAKILAN ONLINE 2026</span>
        </h1>
        <p style="font-size: 17px; color: #94A3B8; max-width: 720px; margin: 0 auto 28px auto; line-height: 1.6;">
          "Rancangan Tampilan Portal Anggota dan Portal Admin"
        </p>
        <div style="display: inline-block; background: #1E3A8A; color: #FFFFFF; padding: 10px 24px; border-radius: 8px; font-weight: 800; font-size: 13px; letter-spacing: 1.5px; border: 1px solid #3B82F6;">
          DOKUMEN PRESENTASI VISUAL UI / UX
        </div>
      </div>
    `
  },

  // SLIDE 2: STRUKTUR PORTAL
  {
    tag: 'STRUKTUR ARSITEKTUR TAMPILAN',
    title: 'Struktur Pemisahan Dua Portal',
    subtitle: 'Aplikasi terbagi menjadi dua portal mandiri untuk menjamin kemudahan pemilih dan ketertiban administrasi.',
    html: `
      <div style="display: flex; flex-direction: column; align-items: center; margin-bottom: 24px;">
        <div style="background: #1E3A8A; border: 2px solid #3B82F6; color: #FFF; padding: 12px 28px; border-radius: 10px; font-weight: 900; font-size: 16px; letter-spacing: 1px;">
          SISTEM PEMILIHAN PERWAKILAN
        </div>
        <div style="width: 2px; height: 24px; background: #3B82F6;"></div>
        <div style="width: 540px; height: 2px; background: #3B82F6;"></div>
        <div style="width: 540px; display: flex; justify-content: space-between;">
          <div style="width: 2px; height: 20px; background: #3B82F6;"></div>
          <div style="width: 2px; height: 20px; background: #3B82F6;"></div>
        </div>
      </div>

      <div class="grid-2">
        <div class="ui-card" style="background: #1E293B; border-color: #3B82F6; color: #FFF;">
          <div style="font-size: 12px; font-weight: 800; color: #60A5FA; letter-spacing: 1px; margin-bottom: 6px;">PORTAL 01</div>
          <div style="font-size: 20px; font-weight: 900; color: #FFF; margin-bottom: 8px;">PORTAL ANGGOTA</div>
          <div style="background: rgba(59, 130, 246, 0.15); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 6px; padding: 8px 12px; font-size: 13px; font-weight: 700; color: #93C5FD; margin-bottom: 12px;">
            Fungsi: Melakukan Voting
          </div>
          <ul style="font-size: 12.5px; color: #CBD5E1; line-height: 1.7; padding-left: 20px;">
            <li>Digunakan oleh seluruh anggota aktif KOPSYAH.</li>
            <li>Masuk cepat hanya menggunakan email terdaftar.</li>
            <li>Menampilkan profil, kuota bagian, dan bilik suara aman.</li>
            <li>Didesain ramah pengguna untuk layar ponsel maupun laptop.</li>
          </ul>
        </div>

        <div class="ui-card" style="background: #1E293B; border-color: #10B981; color: #FFF;">
          <div style="font-size: 12px; font-weight: 800; color: #34D399; letter-spacing: 1px; margin-bottom: 6px;">PORTAL 02</div>
          <div style="font-size: 20px; font-weight: 900; color: #FFF; margin-bottom: 8px;">PORTAL ADMIN</div>
          <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 6px; padding: 8px 12px; font-size: 13px; font-weight: 700; color: #6EE7B7; margin-bottom: 12px;">
            Fungsi: Mengelola Sistem
          </div>
          <ul style="font-size: 12.5px; color: #CBD5E1; line-height: 1.7; padding-left: 20px;">
            <li>Digunakan khusus oleh Panitia Pemilihan & Administrator.</li>
            <li>Kelola DPT pemilih, import Excel/CSV, dan daftar kandidat.</li>
            <li>Monitoring tingkat partisipasi pemilih secara real-time.</li>
            <li>Kalkulasi kuota 10:1 dan penerbitan Berita Acara resmi.</li>
          </ul>
        </div>
      </div>
    `
  },

  // SLIDE 3: LOGIN PORTAL ANGGOTA
  {
    tag: 'PORTAL ANGGOTA — MOCKUP 01',
    title: 'Halaman Masuk (Login) Anggota',
    subtitle: 'Otentikasi satu pintu yang bersih dan aman: hanya menggunakan email terdaftar di database koperasi.',
    html: `
      <div class="grid-2" style="align-items: center;">
        <div class="browser-frame" style="max-width: 480px; margin: 0 auto;">
          <div class="browser-header">
            <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
            <div class="browser-address">https://kopsyah-ykkap.or.id/voting/login</div>
          </div>
          <div class="browser-content" style="padding: 28px 24px; text-align: center;">
            <div style="font-size: 11px; font-weight: 800; color: #1E3A8A; letter-spacing: 1px;">KOPSYAH YKK AP INDONESIA</div>
            <div style="font-size: 15px; font-weight: 900; color: #0F172A; margin: 4px 0 2px 0;">SISTEM PEMILIHAN ANGGOTA</div>
            <div style="font-size: 12px; font-weight: 800; color: #475569; margin-bottom: 20px;">PERWAKILAN 2026</div>

            <div style="background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 8px; padding: 6px 12px; font-size: 11px; font-weight: 800; color: #1E40AF; display: inline-block; margin-bottom: 16px;">
              PORTAL ANGGOTA
            </div>

            <div style="text-align: left; margin-bottom: 16px;">
              <label style="font-size: 11.5px; font-weight: 700; color: #334155; display: block; margin-bottom: 6px;">
                MASUK DENGAN EMAIL TERDAFTAR:
              </label>
              <input type="text" class="input-mockup" value="budi.santoso@ykk.co.id" readonly style="margin-bottom: 8px;" />
              <button class="btn-primary-mockup" style="width: 100%; padding: 11px;">
                MASUK KE SISTEM →
              </button>
            </div>

            <div style="border-top: 1px solid #E2E8F0; padding-top: 14px; text-align: left; font-size: 11px; color: #475569; display: grid; grid-template-columns: 1fr 1fr; gap: 6px;">
              <div>✓ Email terdaftar</div>
              <div>✓ 1 Anggota 1 Suara</div>
              <div>✓ Pemilihan rahasia</div>
              <div>✓ Suara terverifikasi</div>
            </div>
          </div>
        </div>

        <div class="ui-card" style="background: #1E293B; border-color: #334155; color: #FFF;">
          <div style="font-size: 13px; font-weight: 800; color: #FBBF24; margin-bottom: 12px;">KETENTUAN KHUSUS LOGIN:</div>
          <div style="display: flex; flex-direction: column; gap: 12px; font-size: 12.5px; color: #CBD5E1;">
            <div>
              <strong style="color: #60A5FA;">Hanya 1 Metode Login:</strong><br/>
              Anggota cukup mengetikkan email yang telah tercatat pada database keanggotaan KOPSYAH.
            </div>
            <div>
              <strong style="color: #EF4444;">Tanpa Tombol Pihak Ketiga:</strong><br/>
              Tidak ada login Google, tidak ada akun sosial media, dan tidak ada formulir pendaftaran akun baru untuk mencegah infiltrasi pihak luar.
            </div>
            <div>
              <strong style="color: #10B981;">Validasi Instan:</strong><br/>
              Jika email tidak sesuai dengan master data DPT, sistem langsung menolak akses secara otomatis.
            </div>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 4: DASHBOARD ANGGOTA
  {
    tag: 'PORTAL ANGGOTA — MOCKUP 02',
    title: 'Dashboard Anggota (Tampilan Desktop)',
    subtitle: 'Halaman pembuka pemilih dengan kartu identitas anggota, kuota perwakilan bagian, dan tombol bilik suara.',
    html: `
      <div class="browser-frame" style="height: 480px;">
        <div class="browser-header">
          <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
          <div class="browser-address">https://kopsyah-ykkap.or.id/voting/dashboard</div>
        </div>
        <div class="browser-content" style="display: flex; flex-direction: column; padding: 0;">
          <!-- Top Nav -->
          <div style="background: #1E3A8A; color: #FFF; padding: 10px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div style="font-weight: 800; font-size: 13px; letter-spacing: 0.5px;">
              KOPSYAH YKK AP INDONESIA <span style="font-weight: 400; opacity: 0.8;">| Sistem Pemilihan Perwakilan 2026</span>
            </div>
            <div style="display: flex; gap: 16px; font-size: 12px; font-weight: 600;">
              <span style="border-bottom: 2px solid #FFF; padding-bottom: 2px;">Dashboard</span>
              <span style="opacity: 0.7;">Pemilihan</span>
              <span style="opacity: 0.7;">Informasi</span>
              <span style="opacity: 0.7; color: #FCA5A5;">Keluar</span>
            </div>
          </div>

          <!-- Body Content -->
          <div style="padding: 20px; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px;">
              <div>
                <div style="font-size: 11px; font-weight: 800; color: #64748B; text-transform: uppercase;">SELAMAT DATANG</div>
                <div style="font-size: 22px; font-weight: 900; color: #0F172A;">Budi Santoso</div>
              </div>
              <span class="badge-tag badge-unvoted" style="font-size: 12px; padding: 6px 12px;">BELUM MEMILIH</span>
            </div>

            <div class="grid-2" style="gap: 16px; margin-bottom: 16px;">
              <div class="ui-card">
                <div style="font-size: 12px; font-weight: 800; color: #1E3A8A; margin-bottom: 10px; border-bottom: 1px solid #E2E8F0; padding-bottom: 6px;">
                  INFORMASI ANGGOTA
                </div>
                <table style="width: 100%; font-size: 12px; color: #334155; line-height: 1.8;">
                  <tr><td style="width: 120px; color: #64748B;">Nama:</td><td><strong>Budi Santoso</strong></td></tr>
                  <tr><td style="color: #64748B;">Nomor Anggota:</td><td><strong>AGT-00125</strong></td></tr>
                  <tr><td style="color: #64748B;">NIK:</td><td><strong>123456789</strong></td></tr>
                  <tr><td style="color: #64748B;">Bagian:</td><td><strong style="color: #1E3A8A;">PRODUKSI</strong></td></tr>
                  <tr><td style="color: #64748B;">Status Hak Pilih:</td><td><span class="badge-tag badge-active">AKTIF</span></td></tr>
                </table>
              </div>

              <div style="display: flex; flex-direction: column; gap: 10px;">
                <div class="ui-card" style="background: #EFF6FF; border-color: #BFDBFE; text-align: center; padding: 14px;">
                  <div style="font-size: 11px; font-weight: 800; color: #1E40AF;">PRINSIP UTAMA PEMILIHAN</div>
                  <div style="font-size: 18px; font-weight: 900; color: #1E3A8A; margin: 4px 0;">1 ANGGOTA = 1 SUARA</div>
                  <div style="font-size: 11px; color: #475569;">Kerahasiaan Suara Anda TERJAMIN (Asas LUBER)</div>
                </div>

                <div class="ui-card" style="text-align: center; padding: 16px; background: #F8FAFC;">
                  <div style="font-size: 11px; color: #64748B; margin-bottom: 8px;">Silakan klik tombol di bawah untuk menyalurkan hak suara Anda:</div>
                  <button class="btn-primary-mockup" style="width: 100%; padding: 12px; font-size: 14px;">
                    [ MULAI PEMILIHAN ]
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 5: DASHBOARD ANGGOTA MOBILE
  {
    tag: 'PORTAL ANGGOTA — MOCKUP 03',
    title: 'Dashboard Anggota (Versi Mobile)',
    subtitle: 'Rancangan ergonomis satu tangan untuk memudahkan karyawan mengakses pemilihan melalui smartphone pribadi.',
    html: `
      <div class="grid-2" style="align-items: center;">
        <div class="phone-wrapper">
          <div class="phone-frame">
            <div class="phone-notch"></div>
            <div class="phone-screen">
              <div class="phone-top-bar">
                <span>09:41</span>
                <span>KOPSYAH YKK AP</span>
                <span>LTE 100%</span>
              </div>
              <div class="phone-content">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                  <div style="font-size: 10px; font-weight: 800; color: #1E3A8A;">DASHBOARD PEMILIH</div>
                  <span class="badge-tag badge-unvoted" style="font-size: 9px;">BELUM MEMILIH</span>
                </div>

                <div style="background: #FFF; border: 1px solid #E2E8F0; border-radius: 10px; padding: 12px; margin-bottom: 12px;">
                  <div style="font-size: 10px; color: #64748B;">Nama Pemilih:</div>
                  <div style="font-size: 16px; font-weight: 900; color: #0F172A;">Budi Santoso</div>
                  <div style="font-size: 11px; font-weight: 700; color: #1E3A8A; margin-top: 2px;">PRODUKSI</div>

                  <div style="display: flex; justify-content: space-between; margin-top: 8px; padding-top: 8px; border-top: 1px solid #F1F5F9; font-size: 10.5px;">
                    <span style="color: #64748B;">Hak Pilih: <strong style="color:#059669;">AKTIF</strong></span>
                    <span style="color: #64748B;">No: <strong>AGT-00125</strong></span>
                  </div>
                </div>

                <div style="background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 8px; padding: 10px; text-align: center; margin-bottom: 12px;">
                  <div style="font-size: 10px; font-weight: 800; color: #1E40AF;">1 ANGGOTA = 1 SUARA</div>
                  <div style="font-size: 9.5px; color: #475569; margin-top: 2px;">Pilihan bersifat rahasia dan aman.</div>
                </div>

                <div style="margin-top: auto;">
                  <button class="btn-primary-mockup" style="width: 100%; padding: 13px; font-size: 13px; border-radius: 10px;">
                    [ MULAI PEMILIHAN ]
                  </button>
                  <div style="text-align: center; font-size: 9.5px; color: #64748B; margin-top: 6px;">
                    Pastikan koneksi internet Anda stabil
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="ui-card" style="background: #1E293B; border-color: #334155; color: #FFF;">
          <div style="font-size: 13px; font-weight: 800; color: #60A5FA; margin-bottom: 12px;">KEUNGGULAN DESAIN MOBILE:</div>
          <ul style="font-size: 12.5px; color: #CBD5E1; line-height: 1.8; padding-left: 20px;">
            <li><strong>Desain Ramah Satu Tangan (One-Thumb):</strong> Tombol utama berada di area jangkauan jempol bawah layar.</li>
            <li><strong>Visibilitas Tinggi di Lantai Pabrik:</strong> Kontras teks tajam sehingga mudah terbaca bahkan dalam kondisi cahaya terang.</li>
            <li><strong>Ringan & Bebas Unduhan:</strong> Dibuka langsung lewat browser ponsel karyawan tanpa install aplikasi Play Store.</li>
            <li><strong>Responsif Otomatis:</strong> Menyesuaikan proporsi layar pada berbagai merek smartphone (Android & iPhone).</li>
          </ul>
        </div>
      </div>
    `
  },

  // SLIDE 6: HALAMAN PEMILIHAN ANGGOTA
  {
    tag: 'PORTAL ANGGOTA — MOCKUP 04',
    title: 'Halaman Pemilihan (Surat Suara Digital)',
    subtitle: 'Bilik suara dengan perlindungan Radio Button tunggal: pemilih hanya dapat memilih tepat 1 kandidat.',
    html: `
      <div class="grid-2" style="align-items: center;">
        <div class="browser-frame">
          <div class="browser-header">
            <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
            <div class="browser-address">https://kopsyah-ykkap.or.id/voting/ballot</div>
          </div>
          <div class="browser-content" style="padding: 16px;">
            <div style="background: #1E3A8A; color: #FFF; padding: 10px 14px; border-radius: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 10px; opacity: 0.8; font-weight: 700;">PEMILIHAN PERWAKILAN</div>
                <div style="font-size: 15px; font-weight: 900;">Bagian: PRODUKSI</div>
              </div>
              <div style="text-align: right; font-size: 11px;">
                <div>Jumlah Anggota: <strong>47</strong></div>
                <div>Jumlah Kursi: <strong style="color: #93C5FD;">5 Kursi</strong></div>
              </div>
            </div>

            <div style="font-size: 11.5px; color: #334155; margin-bottom: 10px; background: #FFFBEB; border: 1px solid #FDE68A; padding: 6px 10px; border-radius: 6px;">
              Instruksi: <strong>"Silakan pilih 1 kandidat yang menurut Anda paling layak menjadi perwakilan."</strong>
            </div>

            <div class="radio-row checked">
              <div class="radio-dot"><div class="radio-dot-inner"></div></div>
              <div><strong style="color: #1E3A8A;">01</strong> — <span style="font-weight: 800;">BUDI SANTOSO</span></div>
            </div>
            <div class="radio-row">
              <div class="radio-dot"><div class="radio-dot-inner"></div></div>
              <div><strong style="color: #64748B;">02</strong> — <span style="font-weight: 700;">ANDI WIJAYA</span></div>
            </div>
            <div class="radio-row">
              <div class="radio-dot"><div class="radio-dot-inner"></div></div>
              <div><strong style="color: #64748B;">03</strong> — <span style="font-weight: 700;">RUDI HARTONO</span></div>
            </div>
            <div class="radio-row">
              <div class="radio-dot"><div class="radio-dot-inner"></div></div>
              <div><strong style="color: #64748B;">04</strong> — <span style="font-weight: 700;">DEDI SAPUTRA</span></div>
            </div>
            <div class="radio-row">
              <div class="radio-dot"><div class="radio-dot-inner"></div></div>
              <div><strong style="color: #64748B;">05</strong> — <span style="font-weight: 700;">SITI RAHMA</span></div>
            </div>

            <div style="margin-top: 10px; display: flex; justify-content: space-between; align-items: center;">
              <div style="font-size: 11px; font-weight: 800; color: #059669;">PILIHAN ANDA: 1 KANDIDAT</div>
              <button class="btn-primary-mockup" style="padding: 8px 16px;">
                [ KONFIRMASI PILIHAN ]
              </button>
            </div>
          </div>
        </div>

        <div class="ui-card" style="background: #1E293B; border-color: #334155; color: #FFF;">
          <div style="font-size: 13px; font-weight: 800; color: #F59E0B; margin-bottom: 12px;">KEBIJAKAN KETAT BILIK SUARA:</div>
          <div style="display: flex; flex-direction: column; gap: 12px; font-size: 12.5px; color: #CBD5E1;">
            <div>
              <strong style="color: #EF4444;">1. DILARANG MENGGUNAKAN CHECKBOX:</strong><br/>
              Sistem secara absolut menggunakan Radio Button agar mustahil mencoblos lebih dari 1 nama secara teknis.
            </div>
            <div>
              <strong style="color: #6EE7B7;">2. Pemahaman Kuota 5 Kursi:</strong><br/>
              Meskipun Bagian Produksi memiliki kuota 5 kursi perwakilan, setiap anggota tetap hanya memberikan <strong>1 suara</strong>.
            </div>
            <div>
              <strong style="color: #93C5FD;">3. Pencegahan Misinformasi:</strong><br/>
              Sistem tidak menampilkan kalimat ambigu seperti <em>"Anda boleh memilih maksimal 5"</em>.
            </div>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 7: KONFIRMASI SUARA
  {
    tag: 'PORTAL ANGGOTA — MOCKUP 05',
    title: 'Halaman Konfirmasi Suara',
    subtitle: 'Langkah verifikasi ulang guna memastikan anggota yakin dengan pilihannya sebelum suara dikunci secara permanen.',
    html: `
      <div style="max-width: 600px; margin: 0 auto;">
        <div class="ui-card" style="box-shadow: 0 16px 36px rgba(0, 0, 0, 0.4); border: 2px solid #1E3A8A; padding: 28px; text-align: center;">
          <div style="width: 50px; height: 50px; background: #EFF6FF; border: 2px solid #3B82F6; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 14px auto; color: #1E3A8A; font-size: 24px; font-weight: 900;">
            ?
          </div>

          <div style="font-size: 20px; font-weight: 900; color: #0F172A; margin-bottom: 6px;">
            KONFIRMASI PILIHAN
          </div>
          <div style="font-size: 13px; color: #64748B; margin-bottom: 20px;">
            Mohon periksa kembali calon perwakilan yang Anda pilih:
          </div>

          <div style="background: #F8FAFC; border: 1px solid #CBD5E1; border-radius: 10px; padding: 16px; margin-bottom: 20px; text-align: left;">
            <div style="font-size: 11px; font-weight: 800; color: #64748B; text-transform: uppercase;">Anda Memilih:</div>
            <div style="font-size: 20px; font-weight: 900; color: #1E3A8A; margin: 4px 0;">
              01 — BUDI SANTOSO
            </div>
            <div style="font-size: 12px; font-weight: 700; color: #475569;">
              Bagian: PRODUKSI (KOPSYAH YKK AP INDONESIA)
            </div>
          </div>

          <div style="background: #FEF2F2; border: 1px solid #FECACA; border-radius: 8px; padding: 12px; margin-bottom: 24px; text-align: left;">
            <div style="font-size: 12px; font-weight: 800; color: #991B1B; margin-bottom: 2px;">PERINGATAN INTEGRITAS SUARA:</div>
            <div style="font-size: 11.5px; color: #7F1D1D; line-height: 1.5;">
              • Pastikan pilihan Anda sudah benar.<br/>
              • Setelah suara dikirim, pilihan <strong>TIDAK DAPAT DIUBAH</strong> kembali dengan alasan apapun.
            </div>
          </div>

          <div style="display: flex; gap: 12px; justify-content: center;">
            <button style="background: #F1F5F9; border: 1px solid #CBD5E1; color: #334155; padding: 10px 24px; border-radius: 8px; font-weight: 700; font-size: 13px; cursor: pointer;">
              [ KEMBALI ]
            </button>
            <button class="btn-success-mockup" style="padding: 10px 32px; font-size: 13px;">
              [ KIRIM SUARA SEKARANG ]
            </button>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 8: VOTING BERHASIL
  {
    tag: 'PORTAL ANGGOTA — MOCKUP 06',
    title: 'Halaman Konfirmasi Berhasil (Sukses)',
    subtitle: 'Penerbitan bukti digital pemungutan suara resmi tanpa membuka identitas calon demi menjaga asas LUBER.',
    html: `
      <div style="max-width: 620px; margin: 0 auto;">
        <div class="ui-card" style="box-shadow: 0 16px 36px rgba(0, 0, 0, 0.4); border: 2px solid #059669; padding: 28px; text-align: center;">
          <div style="width: 54px; height: 54px; background: #DCFCE7; border: 2px solid #10B981; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px auto; color: #059669; font-size: 26px; font-weight: 900;">
            ✓
          </div>

          <div style="font-size: 22px; font-weight: 900; color: #065F46; margin-bottom: 4px;">
            PEMILIHAN BERHASIL!
          </div>
          <div style="font-size: 13px; color: #475569; margin-bottom: 20px;">
            Terima kasih. Suara Anda telah berhasil direkam secara aman ke dalam sistem.
          </div>

          <div style="background: #F0FDF4; border: 1px solid #BBF7D0; border-radius: 10px; padding: 14px 18px; margin-bottom: 18px; display: flex; justify-content: space-between; align-items: center; text-align: left;">
            <div>
              <div style="font-size: 10px; font-weight: 800; color: #166534; text-transform: uppercase;">ID TRANSAKSI RESMI</div>
              <div style="font-size: 16px; font-weight: 900; color: #0F172A; font-family: monospace;">VOTE-2026-000125</div>
            </div>
            <span class="badge-tag" style="background: #059669; color: #FFF; font-size: 11px; padding: 5px 12px;">
              SUARA TERVERIFIKASI
            </span>
          </div>

          <div style="font-size: 12px; color: #475569; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 12px; margin-bottom: 20px; line-height: 1.5;">
            <strong>Anda telah menggunakan hak pilih Anda.</strong><br/>
            Sesuai AD/ART Koperasi mengenai kerahasiaan suara (LUBER), nama calon pilihan Anda tidak dicantumkan di lembar bukti publik ini.
          </div>

          <div style="display: flex; gap: 10px; justify-content: center;">
            <button class="btn-primary-mockup" style="padding: 10px 20px; font-size: 12px;">
              CETAK BUKTI PEMILIHAN
            </button>
            <button style="background: #FFFFFF; border: 1px solid #CBD5E1; color: #334155; padding: 10px 20px; border-radius: 8px; font-weight: 700; font-size: 12px;">
              KEMBALI KE DASHBOARD
            </button>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 9: LOGIN ADMIN
  {
    tag: 'PORTAL ADMIN — MOCKUP 01',
    title: 'Halaman Masuk (Login) Khusus Administrator',
    subtitle: 'Gerbang otentikasi terpisah dengan kredensial terproteksi untuk mencegah akses tidak berwenang.',
    html: `
      <div class="grid-2" style="align-items: center;">
        <div class="browser-frame" style="max-width: 480px; margin: 0 auto; border-color: #1E3A8A;">
          <div class="browser-header" style="background: #0F172A; color: #FFF; border-bottom: 1px solid #334155;">
            <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
            <div class="browser-address" style="background: #1E293B; color: #94A3B8; border-color: #334155;">https://kopsyah-ykkap.or.id/admin/login</div>
          </div>
          <div class="browser-content" style="padding: 28px 24px; text-align: center;">
            <div style="font-size: 11px; font-weight: 800; color: #1E3A8A; letter-spacing: 1px;">KOPSYAH YKK AP INDONESIA</div>
            <div style="font-size: 18px; font-weight: 900; color: #0F172A; margin: 4px 0 2px 0;">PORTAL ADMINISTRATOR</div>
            <div style="font-size: 11px; font-weight: 700; color: #64748B; margin-bottom: 18px;">PANITIA PEMILIHAN PERWAKILAN</div>

            <div style="background: #FEF3C7; border: 1px solid #FCD34D; border-radius: 6px; padding: 6px 10px; font-size: 11px; font-weight: 700; color: #92400E; margin-bottom: 16px;">
              Khusus Petugas & Administrator Resmi
            </div>

            <div style="text-align: left; margin-bottom: 16px;">
              <label style="font-size: 11px; font-weight: 700; color: #334155; display: block; margin-bottom: 4px;">Email Admin:</label>
              <input type="text" class="input-mockup" value="admin.koperasi@ykk.co.id" readonly style="margin-bottom: 10px;" />
              
              <label style="font-size: 11px; font-weight: 700; color: #334155; display: block; margin-bottom: 4px;">Password Administrator:</label>
              <input type="password" class="input-mockup" value="••••••••••••" readonly style="margin-bottom: 14px;" />

              <button class="btn-primary-mockup" style="width: 100%; padding: 11px;">
                MASUK SEBAGAI ADMIN →
              </button>
            </div>

            <div style="font-size: 10.5px; color: #64748B; border-top: 1px solid #E2E8F0; padding-top: 10px;">
              Seluruh aktivitas login dicatat dalam Audit Trail Keamanan Koperasi.
            </div>
          </div>
        </div>

        <div class="ui-card" style="background: #1E293B; border-color: #334155; color: #FFF;">
          <div style="font-size: 13px; font-weight: 800; color: #F59E0B; margin-bottom: 12px;">STANDAR KEAMANAN ADMIN:</div>
          <ul style="font-size: 12.5px; color: #CBD5E1; line-height: 1.8; padding-left: 20px;">
            <li><strong>Pemisahan Akses Penuh:</strong> Login Admin tidak terhubung dengan form login anggota umum.</li>
            <li><strong>Autentikasi Ganda:</strong> Memerlukan email terdaftar khusus panitia ditambah kata sandi terenkripsi.</li>
            <li><strong>Role-Based Access Control (RBAC):</strong> Hak akses hanya diberikan kepada panitia yang ditunjuk lewat SK resmi.</li>
          </ul>
        </div>
      </div>
    `
  },

  // SLIDE 10: DASHBOARD ADMIN
  {
    tag: 'PORTAL ADMIN — MOCKUP 02',
    title: 'Dashboard Utama Administrator',
    subtitle: 'Pusat pengawasan pemilihan dengan metrik partisipasi real-time dan navigasi 10 modul manajerial.',
    html: `
      <div class="browser-frame" style="height: 480px;">
        <div class="browser-header">
          <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
          <div class="browser-address">https://kopsyah-ykkap.or.id/admin/dashboard</div>
        </div>
        <div class="browser-content" style="display: flex; padding: 0; background: #F1F5F9;">
          <!-- Sidebar -->
          <div style="width: 190px; background: #0F172A; color: #94A3B8; padding: 14px 10px; display: flex; flex-direction: column; font-size: 11px; gap: 4px;">
            <div style="color: #FFF; font-weight: 800; font-size: 12px; margin-bottom: 10px; padding: 0 6px;">
              ADMINISTRATOR
            </div>
            <div style="background: #1E3A8A; color: #FFF; font-weight: 700; padding: 6px 10px; border-radius: 6px;">● Dashboard</div>
            <div style="padding: 6px 10px;">Data Anggota</div>
            <div style="padding: 6px 10px;">Import Anggota</div>
            <div style="padding: 6px 10px;">Data Bagian</div>
            <div style="padding: 6px 10px;">Data Kandidat</div>
            <div style="padding: 6px 10px;">Pengaturan Pemilihan</div>
            <div style="padding: 6px 10px;">Monitoring</div>
            <div style="padding: 6px 10px;">Hasil Pemilihan</div>
            <div style="padding: 6px 10px;">Laporan & BA</div>
            <div style="padding: 6px 10px;">Audit Log</div>
          </div>

          <!-- Main Stats -->
          <div style="flex: 1; padding: 16px; overflow-y: auto;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
              <div style="font-size: 16px; font-weight: 900; color: #0F172A;">DASHBOARD PEMILIHAN</div>
              <span class="badge-tag" style="background: #059669; color: #FFF;">● PEMILIHAN AKTIF</span>
            </div>

            <div class="grid-4" style="gap: 10px; margin-bottom: 16px;">
              <div class="stat-box">
                <div class="title">TOTAL ANGGOTA</div>
                <div class="num">500</div>
              </div>
              <div class="stat-box">
                <div class="title">BERHAK MEMILIH</div>
                <div class="num" style="color: #1E3A8A;">480</div>
              </div>
              <div class="stat-box">
                <div class="title">SUDAH MEMILIH</div>
                <div class="num" style="color: #059669;">420</div>
              </div>
              <div class="stat-box">
                <div class="title">PARTISIPASI</div>
                <div class="num" style="color: #D97706;">87,5%</div>
              </div>
            </div>

            <!-- Chart -->
            <div class="ui-card" style="padding: 14px;">
              <div style="font-size: 12px; font-weight: 800; color: #1E3A8A; margin-bottom: 12px;">
                PARTISIPASI SUARA PER BAGIAN (REAL-TIME)
              </div>
              <div class="chart-bar-row">
                <div class="chart-name">Produksi (47 Agt)</div>
                <div class="chart-track"><div class="chart-fill elected" style="width: 92%;">92% (43 Suara)</div></div>
              </div>
              <div class="chart-bar-row">
                <div class="chart-name">Engineering (46 Agt)</div>
                <div class="chart-track"><div class="chart-fill" style="width: 87%;">87% (40 Suara)</div></div>
              </div>
              <div class="chart-bar-row">
                <div class="chart-name">HR & GA (16 Agt)</div>
                <div class="chart-track"><div class="chart-fill" style="width: 84%;">84% (14 Suara)</div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 11: HALAMAN DATA ANGGOTA
  {
    tag: 'PORTAL ADMIN — MOCKUP 03',
    title: 'Halaman Pengelolaan Data Anggota (DPT)',
    subtitle: 'Pencarian, pemfilteran divisi, dan pemeliharaan status hak pilih anggota secara terpusat.',
    html: `
      <div class="browser-frame" style="height: 480px;">
        <div class="browser-header">
          <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
          <div class="browser-address">https://kopsyah-ykkap.or.id/admin/members</div>
        </div>
        <div class="browser-content" style="padding: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div style="font-size: 16px; font-weight: 900; color: #0F172A;">DATA MASTER ANGGOTA (DPT)</div>
            <button class="btn-primary-mockup" style="padding: 8px 14px; font-size: 11px;">
              [ + IMPORT DATA ANGGOTA ]
            </button>
          </div>

          <!-- Filters -->
          <div style="display: flex; gap: 8px; margin-bottom: 12px;">
            <input type="text" placeholder="Cari nama / nomor anggota / NIK..." style="flex: 1; padding: 7px 12px; font-size: 11px; border: 1px solid #CBD5E1; border-radius: 6px;" value="Budi" />
            <select style="padding: 7px 10px; font-size: 11px; border: 1px solid #CBD5E1; border-radius: 6px; background: #FFF;"><option>Semua Bagian</option><option selected>Produksi</option></select>
            <select style="padding: 7px 10px; font-size: 11px; border: 1px solid #CBD5E1; border-radius: 6px; background: #FFF;"><option>Semua Status</option><option>Belum Memilih</option></select>
          </div>

          <!-- Table -->
          <table class="mock-table">
            <thead>
              <tr>
                <th>Email Anggota</th>
                <th>Nama Anggota</th>
                <th>No Anggota</th>
                <th>Bagian</th>
                <th>Status</th>
                <th>Hak Pilih</th>
                <th style="text-align: right;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>budi.santoso@ykk.co.id</strong></td>
                <td>Budi Santoso</td>
                <td>AGT-00125</td>
                <td><span class="badge-tag badge-voted">Produksi</span></td>
                <td><span class="badge-tag badge-unvoted">Belum Memilih</span></td>
                <td><span class="badge-tag badge-active">Ya</span></td>
                <td style="text-align: right;">
                  <button style="padding: 3px 7px; font-size: 10px; background: #E2E8F0; border: none; border-radius: 4px;">Lihat</button>
                  <button style="padding: 3px 7px; font-size: 10px; background: #1E3A8A; color: #FFF; border: none; border-radius: 4px;">Edit</button>
                </td>
              </tr>
              <tr>
                <td><strong>andi.wijaya@ykk.co.id</strong></td>
                <td>Andi Wijaya</td>
                <td>AGT-00126</td>
                <td><span class="badge-tag badge-voted">Produksi</span></td>
                <td><span class="badge-tag badge-active">Sudah Memilih</span></td>
                <td><span class="badge-tag badge-active">Ya</span></td>
                <td style="text-align: right;">
                  <button style="padding: 3px 7px; font-size: 10px; background: #E2E8F0; border: none; border-radius: 4px;">Lihat</button>
                  <button style="padding: 3px 7px; font-size: 10px; background: #1E3A8A; color: #FFF; border: none; border-radius: 4px;">Edit</button>
                </td>
              </tr>
              <tr>
                <td><strong>rudi.hartono@ykk.co.id</strong></td>
                <td>Rudi Hartono</td>
                <td>AGT-00127</td>
                <td><span class="badge-tag" style="background:#F1F5F9; color:#475569;">Engineering</span></td>
                <td><span class="badge-tag badge-active">Sudah Memilih</span></td>
                <td><span class="badge-tag badge-active">Ya</span></td>
                <td style="text-align: right;">
                  <button style="padding: 3px 7px; font-size: 10px; background: #E2E8F0; border: none; border-radius: 4px;">Lihat</button>
                  <button style="padding: 3px 7px; font-size: 10px; background: #1E3A8A; color: #FFF; border: none; border-radius: 4px;">Edit</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `
  },

  // SLIDE 12: IMPORT DATA ANGGOTA
  {
    tag: 'PORTAL ADMIN — MOCKUP 04',
    title: 'Halaman Import Data Anggota (Excel / CSV)',
    subtitle: 'Mekanisme pengunggahan massal data pemilih dilengkapi validasi anomali dan duplikasi otomatis.',
    html: `
      <div class="grid-2" style="align-items: center;">
        <div class="browser-frame">
          <div class="browser-header">
            <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
            <div class="browser-address">https://kopsyah-ykkap.or.id/admin/import</div>
          </div>
          <div class="browser-content" style="padding: 16px;">
            <div style="font-size: 14px; font-weight: 900; color: #0F172A; margin-bottom: 2px;">IMPORT DATA ANGGOTA</div>
            <div style="font-size: 11px; color: #64748B; margin-bottom: 12px;">Unggah master data DPT resmi dari file spreadsheet (CSV / Excel).</div>

            <div style="border: 2px dashed #3B82F6; background: #EFF6FF; border-radius: 10px; padding: 24px; text-align: center; margin-bottom: 14px;">
              <div style="font-size: 26px; margin-bottom: 6px;">📂</div>
              <div style="font-size: 13px; font-weight: 800; color: #1E3A8A;">DROP FILE DI SINI</div>
              <div style="font-size: 11px; color: #64748B; margin: 4px 0 8px 0;">atau klik tombol di bawah:</div>
              <button class="btn-primary-mockup" style="padding: 6px 16px; font-size: 11px;">
                [ PILIH FILE EXCEL / CSV ]
              </button>
            </div>

            <!-- Result Box -->
            <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px; font-size: 11px;">
              <div style="font-weight: 800; color: #0F172A; margin-bottom: 4px;">Hasil Analisis File:</div>
              <div style="color: #059669; font-weight: 700;">✓ 480 data valid siap diimport</div>
              <div style="color: #D97706;">⚠ 3 data duplikat nomor anggota (dilewati)</div>
              <div style="color: #DC2626;">⚠ 2 format email tidak valid (dilewati)</div>
            </div>

            <div style="display: flex; gap: 8px; justify-content: flex-end; margin-top: 12px;">
              <button style="padding: 6px 12px; font-size: 11px; border: 1px solid #CBD5E1; background: #FFF; border-radius: 6px;">[ BATAL ]</button>
              <button class="btn-success-mockup" style="padding: 6px 14px; font-size: 11px;">[ IMPORT DATA VALID ]</button>
            </div>
          </div>
        </div>

        <div class="ui-card" style="background: #1E293B; border-color: #334155; color: #FFF;">
          <div style="font-size: 13px; font-weight: 800; color: #6EE7B7; margin-bottom: 12px;">5 TAHAP PROSES IMPORT:</div>
          <div style="display: flex; flex-direction: column; gap: 10px; font-size: 12px; color: #CBD5E1;">
            <div style="display:flex; gap:10px; align-items:center;">
              <span style="background:#1E3A8A; color:#FFF; border-radius:50%; width:20px; height:20px; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:10px;">1</span>
              <span><strong>UPLOAD:</strong> Pilih berkas file data kepegawaian.</span>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
              <span style="background:#1E3A8A; color:#FFF; border-radius:50%; width:20px; height:20px; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:10px;">2</span>
              <span><strong>VALIDASI:</strong> Sistem memverifikasi format email, NIK, dan bagian.</span>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
              <span style="background:#1E3A8A; color:#FFF; border-radius:50%; width:20px; height:20px; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:10px;">3</span>
              <span><strong>PREVIEW:</strong> Tampilkan ringkasan data bersih vs data bermasalah.</span>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
              <span style="background:#1E3A8A; color:#FFF; border-radius:50%; width:20px; height:20px; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:10px;">4</span>
              <span><strong>KONFIRMASI:</strong> Panitia menyetujui pembaruan master data.</span>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
              <span style="background:#059669; color:#FFF; border-radius:50%; width:20px; height:20px; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:10px;">5</span>
              <span><strong>SIMPAN:</strong> Data tersinkronisasi ke DPT sistem.</span>
            </div>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 13: HALAMAN DATA KANDIDAT
  {
    tag: 'PORTAL ADMIN — MOCKUP 05',
    title: 'Halaman Pengelolaan Data Kandidat',
    subtitle: 'Manajemen calon perwakilan per bagian lengkap dengan nomor urut, foto, dan status keaktifan.',
    html: `
      <div class="browser-frame" style="height: 480px;">
        <div class="browser-header">
          <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
          <div class="browser-address">https://kopsyah-ykkap.or.id/admin/candidates</div>
        </div>
        <div class="browser-content" style="padding: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div>
              <div style="font-size: 16px; font-weight: 900; color: #0F172A;">DATA KANDIDAT PERWAKILAN</div>
              <div style="font-size: 11px; color: #64748B;">Filter: Bagian PRODUKSI | Status: AKTIF</div>
            </div>
            <button class="btn-primary-mockup" style="padding: 8px 14px; font-size: 11px;">
              [ + TAMBAH KANDIDAT ]
            </button>
          </div>

          <!-- Candidates Grid -->
          <div class="grid-3" style="gap: 12px;">
            <div class="ui-card" style="border-top: 3px solid #1E3A8A;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <span style="font-size: 18px; font-weight: 900; color: #1E3A8A;">01</span>
                <span class="badge-tag badge-active">AKTIF</span>
              </div>
              <div style="font-size: 14px; font-weight: 800; color: #0F172A;">BUDI SANTOSO</div>
              <div style="font-size: 11px; color: #64748B; margin-bottom: 10px;">Bagian: PRODUKSI</div>
              <div style="display: flex; gap: 6px;">
                <button style="flex:1; padding: 4px; font-size: 10px; background: #E2E8F0; border: none; border-radius: 4px;">EDIT</button>
                <button style="flex:1; padding: 4px; font-size: 10px; background: #FEE2E2; color: #991B1B; border: none; border-radius: 4px;">NONAKTIFKAN</button>
              </div>
            </div>

            <div class="ui-card" style="border-top: 3px solid #1E3A8A;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <span style="font-size: 18px; font-weight: 900; color: #1E3A8A;">02</span>
                <span class="badge-tag badge-active">AKTIF</span>
              </div>
              <div style="font-size: 14px; font-weight: 800; color: #0F172A;">ANDI WIJAYA</div>
              <div style="font-size: 11px; color: #64748B; margin-bottom: 10px;">Bagian: PRODUKSI</div>
              <div style="display: flex; gap: 6px;">
                <button style="flex:1; padding: 4px; font-size: 10px; background: #E2E8F0; border: none; border-radius: 4px;">EDIT</button>
                <button style="flex:1; padding: 4px; font-size: 10px; background: #FEE2E2; color: #991B1B; border: none; border-radius: 4px;">NONAKTIFKAN</button>
              </div>
            </div>

            <div class="ui-card" style="border-top: 3px solid #1E3A8A;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <span style="font-size: 18px; font-weight: 900; color: #1E3A8A;">03</span>
                <span class="badge-tag badge-active">AKTIF</span>
              </div>
              <div style="font-size: 14px; font-weight: 800; color: #0F172A;">RUDI HARTONO</div>
              <div style="font-size: 11px; color: #64748B; margin-bottom: 10px;">Bagian: PRODUKSI</div>
              <div style="display: flex; gap: 6px;">
                <button style="flex:1; padding: 4px; font-size: 10px; background: #E2E8F0; border: none; border-radius: 4px;">EDIT</button>
                <button style="flex:1; padding: 4px; font-size: 10px; background: #FEE2E2; color: #991B1B; border: none; border-radius: 4px;">NONAKTIFKAN</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 14: HALAMAN MONITORING PEMILIHAN
  {
    tag: 'PORTAL ADMIN — MOCKUP 06',
    title: 'Halaman Monitoring Pemilihan Real-Time',
    subtitle: 'Pemantauan persentase kehadiran pemilih per bagian tanpa melanggar kerahasiaan pilihan individu.',
    html: `
      <div class="browser-frame" style="height: 480px;">
        <div class="browser-header">
          <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
          <div class="browser-address">https://kopsyah-ykkap.or.id/admin/monitoring</div>
        </div>
        <div class="browser-content" style="padding: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
            <div>
              <div style="font-size: 16px; font-weight: 900; color: #0F172A;">MONITORING PARTISIPASI PEMILIHAN</div>
              <div style="font-size: 11px; color: #64748B;">Periode 2026 | Pembaharuan otomatis setiap 30 detik</div>
            </div>
            <span class="badge-tag" style="background: #059669; color: #FFF;">● STATUS: AKTIF</span>
          </div>

          <div class="grid-4" style="gap: 10px; margin-bottom: 16px;">
            <div class="stat-box">
              <div class="title">TOTAL HAK PILIH</div>
              <div class="num">480</div>
            </div>
            <div class="stat-box">
              <div class="title">SUDAH MEMILIH</div>
              <div class="num" style="color: #059669;">420</div>
            </div>
            <div class="stat-box">
              <div class="title">BELUM MEMILIH</div>
              <div class="num" style="color: #DC2626;">60</div>
            </div>
            <div class="stat-box">
              <div class="title">PARTISIPASI GLOBAL</div>
              <div class="num" style="color: #1E3A8A;">87,5%</div>
            </div>
          </div>

          <!-- Table -->
          <table class="mock-table">
            <thead>
              <tr>
                <th>Nama Bagian / Divisi</th>
                <th>Total Anggota</th>
                <th>Sudah Memilih</th>
                <th>Belum Memilih</th>
                <th>Tingkat Partisipasi</th>
                <th>Status Kuorum</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Produksi</strong></td>
                <td>47 orang</td>
                <td style="color: #059669; font-weight: 700;">43 orang</td>
                <td style="color: #DC2626;">4 orang</td>
                <td><strong style="color: #1E3A8A;">91,5%</strong></td>
                <td><span class="badge-tag badge-active">Memenuhi Kuorum</span></td>
              </tr>
              <tr>
                <td><strong>Engineering</strong></td>
                <td>46 orang</td>
                <td style="color: #059669; font-weight: 700;">40 orang</td>
                <td style="color: #DC2626;">6 orang</td>
                <td><strong style="color: #1E3A8A;">87,0%</strong></td>
                <td><span class="badge-tag badge-active">Memenuhi Kuorum</span></td>
              </tr>
              <tr>
                <td><strong>HR & GA</strong></td>
                <td>16 orang</td>
                <td style="color: #059669; font-weight: 700;">14 orang</td>
                <td style="color: #DC2626;">2 orang</td>
                <td><strong style="color: #1E3A8A;">87,5%</strong></td>
                <td><span class="badge-tag badge-active">Memenuhi Kuorum</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `
  },

  // SLIDE 15: HALAMAN HASIL PEMILIHAN
  {
    tag: 'PORTAL ADMIN — MOCKUP 07',
    title: 'Halaman Hasil & Penetapan Perwakilan Terpilih',
    subtitle: 'Kalkulasi otomatis kuota 10:1 dan penetapan ranking peraih suara terbanyak per divisi.',
    html: `
      <div class="browser-frame" style="height: 480px;">
        <div class="browser-header">
          <div class="window-dots"><span class="dot dot-red"></span><span class="dot dot-yellow"></span><span class="dot dot-green"></span></div>
          <div class="browser-address">https://kopsyah-ykkap.or.id/admin/results</div>
        </div>
        <div class="browser-content" style="padding: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div>
              <div style="font-size: 16px; font-weight: 900; color: #0F172A;">HASIL PEMILIHAN — BAGIAN PRODUKSI</div>
              <div style="font-size: 11px; color: #64748B;">47 Anggota ÷ 10 = 4,7 → <strong>Alokasi 5 Kursi Perwakilan</strong></div>
            </div>
            <button class="btn-primary-mockup" style="padding: 8px 14px; font-size: 11px;">
              [ CETAK BERITA ACARA ]
            </button>
          </div>

          <div class="grid-2" style="gap: 16px;">
            <!-- Table Ranking -->
            <div>
              <table class="mock-table">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Nama Kandidat</th>
                    <th>Perolehan</th>
                    <th>Status Penetapan</th>
                  </tr>
                </thead>
                <tbody>
                  <tr style="background: #F0FDF4;">
                    <td><strong>#1</strong></td>
                    <td><strong>Budi Santoso</strong></td>
                    <td><strong style="color: #059669;">15 suara</strong></td>
                    <td><span class="badge-tag" style="background:#059669; color:#FFF;">TERPILIH</span></td>
                  </tr>
                  <tr style="background: #F0FDF4;">
                    <td><strong>#2</strong></td>
                    <td><strong>Andi Wijaya</strong></td>
                    <td><strong style="color: #059669;">11 suara</strong></td>
                    <td><span class="badge-tag" style="background:#059669; color:#FFF;">TERPILIH</span></td>
                  </tr>
                  <tr style="background: #F0FDF4;">
                    <td><strong>#3</strong></td>
                    <td><strong>Rudi Hartono</strong></td>
                    <td><strong style="color: #059669;">8 suara</strong></td>
                    <td><span class="badge-tag" style="background:#059669; color:#FFF;">TERPILIH</span></td>
                  </tr>
                  <tr style="background: #F0FDF4;">
                    <td><strong>#4</strong></td>
                    <td><strong>Dedi Saputra</strong></td>
                    <td><strong style="color: #059669;">5 suara</strong></td>
                    <td><span class="badge-tag" style="background:#059669; color:#FFF;">TERPILIH</span></td>
                  </tr>
                  <tr style="background: #F0FDF4;">
                    <td><strong>#5</strong></td>
                    <td><strong>Siti Rahma</strong></td>
                    <td><strong style="color: #059669;">3 suara</strong></td>
                    <td><span class="badge-tag" style="background:#059669; color:#FFF;">TERPILIH</span></td>
                  </tr>
                  <tr>
                    <td>#6</td>
                    <td>Kandidat F</td>
                    <td>2 suara</td>
                    <td><span class="badge-tag" style="background:#E2E8F0; color:#64748B;">Tidak Terpilih</span></td>
                  </tr>
                </tbody>
              </table>
            </div>

            <!-- Graphic Chart -->
            <div class="ui-card" style="padding: 12px; display: flex; flex-direction: column; justify-content: space-between;">
              <div style="font-size: 11px; font-weight: 800; color: #1E3A8A; margin-bottom: 8px;">GRAFIK PEROLEHAN SUARA</div>
              <div class="chart-bar-row">
                <div class="chart-name">Budi Santoso</div>
                <div class="chart-track"><div class="chart-fill elected" style="width: 100%;">15 Suara</div></div>
              </div>
              <div class="chart-bar-row">
                <div class="chart-name">Andi Wijaya</div>
                <div class="chart-track"><div class="chart-fill elected" style="width: 73%;">11 Suara</div></div>
              </div>
              <div class="chart-bar-row">
                <div class="chart-name">Rudi Hartono</div>
                <div class="chart-track"><div class="chart-fill elected" style="width: 53%;">8 Suara</div></div>
              </div>
              <div class="chart-bar-row">
                <div class="chart-name">Dedi Saputra</div>
                <div class="chart-track"><div class="chart-fill elected" style="width: 33%;">5 Suara</div></div>
              </div>
              <div class="chart-bar-row">
                <div class="chart-name">Siti Rahma</div>
                <div class="chart-track"><div class="chart-fill elected" style="width: 20%;">3 Suara</div></div>
              </div>
              <div style="background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 6px; padding: 6px 10px; font-size: 10.5px; color: #1E40AF; margin-top: 6px;">
                5 peraih suara terbanyak otomatis menempati kuota 5 kursi perwakilan.
              </div>
            </div>
          </div>
        </div>
      </div>
    `
  },

  // SLIDE 16: RINGKASAN TAMPILAN (STORYBOARD UI)
  {
    tag: 'RINGKASAN MENYELURUH',
    title: 'Storyboard Alur Antarmuka Sistem',
    subtitle: 'Rangkuman visual 12 layar utama yang menghubungkan seluruh siklus hidup pemilihan perwakilan.',
    html: `
      <div class="grid-4" style="gap: 10px;">
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #3B82F6;">
          <div style="font-size: 10px; font-weight: 800; color: #60A5FA;">01. PORTAL PEMILIH</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Login Anggota</div>
          <div style="font-size: 10px; color: #64748B;">Hanya email terdaftar database.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #3B82F6;">
          <div style="font-size: 10px; font-weight: 800; color: #60A5FA;">02. PORTAL PEMILIH</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Dashboard Desktop</div>
          <div style="font-size: 10px; color: #64748B;">Profil, kuota kursi, status hak.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #3B82F6;">
          <div style="font-size: 10px; font-weight: 800; color: #60A5FA;">03. PORTAL PEMILIH</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Dashboard Mobile</div>
          <div style="font-size: 10px; color: #64748B;">Desain ramah satu jempol di HP.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #3B82F6;">
          <div style="font-size: 10px; font-weight: 800; color: #60A5FA;">04. BILIK SUARA</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Halaman Voting</div>
          <div style="font-size: 10px; color: #64748B;">Radio Button wajib (pilih 1).</div>
        </div>

        <div class="ui-card" style="padding: 10px; border-left: 3px solid #10B981;">
          <div style="font-size: 10px; font-weight: 800; color: #059669;">05. BILIK SUARA</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Konfirmasi Pilihan</div>
          <div style="font-size: 10px; color: #64748B;">Peringatan sebelum suara dikunci.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #10B981;">
          <div style="font-size: 10px; font-weight: 800; color: #059669;">06. BILIK SUARA</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Bukti Voting Sah</div>
          <div style="font-size: 10px; color: #64748B;">ID transaksi & tombol cetak.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #F59E0B;">
          <div style="font-size: 10px; font-weight: 800; color: #D97706;">07. PORTAL ADMIN</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Login Admin</div>
          <div style="font-size: 10px; color: #64748B;">Otentikasi terpisah panitia.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #F59E0B;">
          <div style="font-size: 10px; font-weight: 800; color: #D97706;">08. PORTAL ADMIN</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Dashboard Admin</div>
          <div style="font-size: 10px; color: #64748B;">Grafik partisipasi real-time.</div>
        </div>

        <div class="ui-card" style="padding: 10px; border-left: 3px solid #8B5CF6;">
          <div style="font-size: 10px; font-weight: 800; color: #7C3AED;">09. DATA MANAGEMENT</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Kelola Data Anggota</div>
          <div style="font-size: 10px; color: #64748B;">Filter divisi dan status memilih.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #8B5CF6;">
          <div style="font-size: 10px; font-weight: 800; color: #7C3AED;">10. DATA MANAGEMENT</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Import Excel/CSV</div>
          <div style="font-size: 10px; color: #64748B;">Validasi duplikasi otomatis.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #8B5CF6;">
          <div style="font-size: 10px; font-weight: 800; color: #7C3AED;">11. PENGAWASAN</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Monitoring Suara</div>
          <div style="font-size: 10px; color: #64748B;">Kuorum per divisi transparan.</div>
        </div>
        <div class="ui-card" style="padding: 10px; border-left: 3px solid #8B5CF6;">
          <div style="font-size: 10px; font-weight: 800; color: #7C3AED;">12. PENETAPAN</div>
          <div style="font-size: 12px; font-weight: 800; color: #0F172A;">Hasil & Berita Acara</div>
          <div style="font-size: 10px; color: #64748B;">Penetapan otomatis kuota 10:1.</div>
        </div>
      </div>
    `
  }
];

const js = `
let currentSlide = 0;
const totalSlides = ${slides.length};

const slides = document.querySelectorAll('.slide');
const progressBar = document.getElementById('progressBar');
const slideCounter = document.getElementById('slideCounter');
const btnPrev = document.getElementById('btnPrev');
const btnNext = document.getElementById('btnNext');
const overviewOverlay = document.getElementById('overviewOverlay');

// 1. Teks Narasi untuk Setiap Slide Presentasi (1 - 16)
const narasiPerSlide = {
  1: "Selamat datang di Presentasi Mockup Sistem Pemilihan Anggota Perwakilan Online KOPSYAH PT YKK AP Indonesia tahun 2026. Dokumen ini memperlihatkan rancangan tampilan antarmuka Portal Anggota dan Portal Admin untuk evaluasi dan persetujuan pimpinan.",
  2: "Sistem pemilihan dirancang dengan memisahkan dua portal utama: Portal Anggota khusus untuk melakukan pemungutan suara, dan Portal Admin khusus bagi panitia untuk mengelola anggota, kandidat, dan rekapitulasi hasil.",
  3: "Pada halaman login anggota, sistem menerapkan kebijakan satu pintu yang sangat aman: pemilih hanya dapat masuk menggunakan alamat email resmi yang telah terdaftar di database koperasi, tanpa tombol login pihak ketiga.",
  4: "Setelah berhasil masuk, anggota diarahkan ke Dashboard yang memuat kartu informasi identitas, nomor anggota, bagian kerja, status hak pilih, serta tombol utama Mulai Pemilihan dengan jaminan kerahasiaan suara.",
  5: "Sistem juga dioptimalkan secara responsif untuk layar smartphone dengan tata letak satu tangan, memudahkan karyawan melakukan pemilihan langsung dari ponsel pribadi di lantai pabrik maupun kantor.",
  6: "Di bilik suara digital, daftar kandidat se-bagian disajikan menggunakan Radio Button tunggal. Setiap anggota hanya dapat memilih tepat satu kandidat perwakilan dari bagian kerjanya, menjamin kepatuhan asas satu anggota satu suara.",
  7: "Sebelum suara dikirim ke database, sistem menampilkan dialog konfirmasi untuk memastikan ketepatan pilihan. Pemilih diingatkan bahwa setelah suara terkirim, pilihan tidak dapat diubah kembali.",
  8: "Setelah pengiriman suara sukses, sistem menerbitkan bukti transaksi digital resmi dengan ID unik. Demi menjaga kerahasiaan dan asas LUBER, identitas kandidat yang dipilih tidak ditampilkan pada bukti publik.",
  9: "Portal Administrator memiliki gerbang masuk terpisah dengan pengamanan ganda berupa email panitia dan kata sandi terenkripsi, memastikan hanya panitia berwenang yang dapat mengakses kontrol sistem.",
  10: "Dashboard Admin menyajikan pusat monitoring real-time yang menampilkan statistik total 500 anggota, 480 berhak memilih, 420 suara masuk, persentase partisipasi 87,5 persen, serta grafik progres per bagian kerja.",
  11: "Panitia dapat mengelola Daftar Pemilih Tetap secara terpusat, lengkap dengan fitur pencarian cepat, filter berdasarkan divisi atau bagian kerja, serta kontrol status keaktifan hak pilih.",
  12: "Untuk mempermudah pemutakhiran data, panitia dapat mengunggah berkas Excel atau CSV dengan alur lima tahapan validasi otomatis yang mendeteksi data duplikat maupun format email yang tidak valid.",
  13: "Halaman kandidat menampilkan daftar calon perwakilan per divisi lengkap dengan nomor urut, bagian, dan status keaktifan, yang siap disajikan pada surat suara digital anggota.",
  14: "Panitia dapat memantau kuorum dan tingkat partisipasi setiap bagian kerja secara langsung melalui tabel monitoring, memastikan proses pemilihan berjalan lancar hingga batas waktu yang ditentukan.",
  15: "Hasil perolehan suara disajikan secara transparan melalui grafik dan tabel peringkat. Sistem secara otomatis menerapkan rasio 10 banding 1 untuk menetapkan lima kandidat peraih suara terbanyak pada Bagian Produksi sebagai perwakilan terpilih.",
  16: "Sebagai kesimpulan, storyboard ini memperlihatkan keseluruhan alur antarmuka aplikasi dari hulu ke hilir yang modern, bersih, aman, dan siap diimplementasikan untuk KOPSYAH PT YKK AP Indonesia."
};

let audioAktif = true;
let userHasInteracted = false;

// 2. Fungsi Utama Pemutar Suara Narasi
function putarNarasi(nomorSlide) {
  if (!audioAktif || !('speechSynthesis' in window)) return;
  
  // Hentikan narasi sebelumnya jika slide berpindah
  window.speechSynthesis.cancel();

  const teks = narasiPerSlide[nomorSlide];
  if (!teks) return;

  const narator = new SpeechSynthesisUtterance(teks);
  narator.lang = 'id-ID'; // Bahasa Indonesia
  narator.rate = 0.92;   // Kecepatan bicara yang nyaman dan jelas
  narator.pitch = 1.0;

  window.speechSynthesis.speak(narator);
}

function updateSlide(index) {
  if (index < 0) index = 0;
  if (index >= totalSlides) index = totalSlides - 1;
  currentSlide = index;

  slides.forEach((s, idx) => {
    s.classList.toggle('active', idx === currentSlide);
  });

  const percent = ((currentSlide + 1) / totalSlides) * 100;
  progressBar.style.width = percent + '%';
  slideCounter.textContent = 'Slide ' + (currentSlide + 1) + ' / ' + totalSlides;

  btnPrev.disabled = currentSlide === 0;
  btnNext.disabled = currentSlide === totalSlides - 1;

  document.querySelectorAll('.overview-card').forEach((c, idx) => {
    c.classList.toggle('active', idx === currentSlide);
  });

  // Mainkan narasi suara untuk slide aktif jika audio aktif
  if (audioAktif && userHasInteracted) {
    putarNarasi(currentSlide + 1);
  }
}

function nextSlide() { 
  userHasInteracted = true;
  updateSlide(currentSlide + 1); 
}
function prevSlide() { 
  userHasInteracted = true;
  updateSlide(currentSlide - 1); 
}
function firstSlide() { 
  userHasInteracted = true;
  updateSlide(0); 
}
function lastSlide() { 
  userHasInteracted = true;
  updateSlide(totalSlides - 1); 
}

function toggleOverview() {
  overviewOverlay.classList.toggle('open');
}

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch(() => {});
  } else {
    document.exitFullscreen().catch(() => {});
  }
}

document.addEventListener('keydown', (e) => {
  userHasInteracted = true;
  if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') {
    e.preventDefault();
    nextSlide();
  } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
    e.preventDefault();
    prevSlide();
  } else if (e.key === 'Home') {
    e.preventDefault();
    firstSlide();
  } else if (e.key === 'End') {
    e.preventDefault();
    lastSlide();
  } else if (e.key === 'f' || e.key === 'F') {
    toggleFullscreen();
  } else if (e.key === 'o' || e.key === 'O' || e.key === 'Escape') {
    if (overviewOverlay.classList.contains('open')) {
      toggleOverview();
    } else if (e.key !== 'Escape') {
      toggleOverview();
    }
  }
});

// Inisialisasi slide pertama
updateSlide(0);

// Aktifkan pemutaran saat klik pertama di halaman untuk mematuhi kebijakan autoplay browser
document.addEventListener('click', function initAudioGesture() {
  if (!userHasInteracted) {
    userHasInteracted = true;
    if (audioAktif) {
      putarNarasi(currentSlide + 1);
    }
  }
}, { once: true });
`;

const slidesHtml = slides.map((s, idx) => `
        <section class="slide ${idx === 0 ? 'active' : ''}" id="slide-${idx}">
          <div class="slide-tag">${s.tag}</div>
          <h2 class="slide-title">${s.title}</h2>
          <div class="slide-subtitle">${s.subtitle}</div>
          <div class="slide-body">
            ${s.html}
          </div>
        </section>
      `).join('');

const overviewCardsHtml = slides.map((s, idx) => `
        <div class="overview-card" onclick="updateSlide(${idx}); toggleOverview(); userHasInteracted = true; if (audioAktif) putarNarasi(${idx + 1});">
          <div class="num">SLIDE ${idx + 1}</div>
          <div class="name">${s.title}</div>
        </div>
      `).join('');

const html = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MOCKUP INTERFACE SISTEM PEMILIHAN ANGGOTA — KOPSYAH YKK AP INDONESIA</title>
  <style>
${css}
  </style>
</head>
<body>
  <!-- Header Bar -->
  <header class="pres-header">
    <div class="pres-brand">
      <span class="pres-badge">KOPSYAH YKK AP</span>
      <span class="pres-title-header">MOCKUP SISTEM PEMILIHAN PERWAKILAN 2026</span>
    </div>
    <div class="pres-tools">
      <button class="btn-tool" onclick="toggleOverview()" title="Daftar Slide (O)">
        ☰ Ringkasan Slide
      </button>
      <button class="btn-tool" onclick="toggleFullscreen()" title="Layar Penuh (F)">
        ⛶ Layar Penuh
      </button>
      <button class="btn-tool" onclick="window.print()" title="Cetak / Unduh PDF">
        🖨 Cetak Presentasi
      </button>
    </div>
  </header>

  <!-- Progress Bar -->
  <div class="progress-container">
    <div class="progress-bar" id="progressBar"></div>
  </div>

  <!-- Stage -->
  <main class="stage-container">
    <div class="slide-viewport">
${slidesHtml}
    </div>
  </main>

  <!-- Footer Navigation -->
  <footer class="pres-footer">
    <div class="footer-info">
      <span class="footer-counter" id="slideCounter">Slide 1 / ${slides.length}</span>
      <span>Gunakan tombol panah keyboard (← / →) atau tombol di kanan</span>
    </div>
    <div class="footer-actions">
      <button class="btn-nav" onclick="firstSlide()" title="Slide Pertama (Home)">⇤ Awal</button>
      <button class="btn-nav" id="btnPrev" onclick="prevSlide()" title="Sebelumnya (←)">← Sebelumnya</button>
      <button class="btn-nav" id="btnNext" onclick="nextSlide()" title="Berikutnya (→)">Berikutnya →</button>
    </div>
  </footer>

  <!-- Overview Modal -->
  <div class="overview-overlay" id="overviewOverlay">
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); padding-bottom: 14px;">
      <div style="font-size: 18px; font-weight: 900; color: #FFF;">DAFTAR SLIDE MOCKUP UI / UX</div>
      <button class="btn-tool" onclick="toggleOverview()">✕ Tutup (Esc)</button>
    </div>
    <div class="overview-grid">
${overviewCardsHtml}
    </div>
  </div>

  <script>
${js}

  // 3. Tombol Kontrol Suara (Mute/Unmute) di Layar
  const tombolAudio = document.createElement('button');
  tombolAudio.innerHTML = '🔊 Suara: AKTIF';
  tombolAudio.id = 'btnAudioToggle';
  tombolAudio.title = 'Nyalakan / Matikan Narasi Suara Otomatis';
  tombolAudio.style.cssText = \`
    position: fixed; top: 8px; right: 420px; z-index: 99999;
    padding: 7px 14px; background: #1E3A8A; color: #FFF;
    border: 1px solid #3B82F6; border-radius: 6px; font-weight: bold;
    font-size: 12px; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s;
  \`;

  tombolAudio.onclick = () => {
    userHasInteracted = true;
    audioAktif = !audioAktif;
    if (!audioAktif) {
      window.speechSynthesis.cancel();
      tombolAudio.innerHTML = '🔇 Suara: MATI';
      tombolAudio.style.background = '#4B5563';
      tombolAudio.style.borderColor = '#6B7280';
    } else {
      tombolAudio.innerHTML = '🔊 Suara: AKTIF';
      tombolAudio.style.background = '#1E3A8A';
      tombolAudio.style.borderColor = '#3B82F6';
      if (typeof currentSlide !== 'undefined') putarNarasi(currentSlide + 1);
    }
  };
  document.body.appendChild(tombolAudio);
  </script>
</body>
</html>
`;

fs.writeFileSync(path.join(__dirname, 'presentation-ui.html'), html, 'utf8');
console.log('Successfully written presentation-ui.html');

try {
  fs.writeFileSync(path.join(__dirname, 'public', 'presentation-ui.html'), html, 'utf8');
  console.log('Successfully written public/presentation-ui.html');
} catch (e) {
  console.log('Public directory note:', e.message);
}
